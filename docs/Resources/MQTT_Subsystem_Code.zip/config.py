# config.py — MQTT broker + WiFi configuration for Damian's MQTT bridge
# imports shared constants from team_config

from team_config import (
    MQTT_SERVER, MQTT_USER, MQTT_PASSWORD,
    TOPIC_HB, TOPIC_PUB, TOPIC_SUB,
    WIFI_NETWORKS,
)

# primary WiFi (first network in the list)
WIFI_SSID    = WIFI_NETWORKS[0][0]
WIFI_PASSWORD = WIFI_NETWORKS[0][1]

# re-export for main.py
__all__ = [
    'MQTT_SERVER', 'MQTT_USER', 'MQTT_PASSWORD',
    'TOPIC_HB', 'TOPIC_PUB', 'TOPIC_SUB',
    'WIFI_SSID', 'WIFI_PASSWORD',
]
