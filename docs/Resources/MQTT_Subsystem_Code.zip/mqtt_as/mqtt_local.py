# mqtt_local.py Local configuration for mqtt_as demo programs.
from sys import platform, implementation
from mqtt_as.mqtt_as import config

# For demos ensure same calling convention for LED's on all platforms.
# ESP8266 Feather Huzzah reference board has active low LED's on pins 0 and 2.
# ESP32 is assumed to have user supplied active low LED's on same pins.
# Call with blue_led(True) to light

if platform == 'esp8266' or platform == 'esp32':
    # Damian's board has no LEDs or buttons — no-op everything
    wifi_led = lambda _ : None
    blue_led = lambda _ : None
elif platform == 'pyboard':
    from pyb import LED
    def ledfunc(led, init):
        led = led
        led.on() if init else led.off()
        def func(v):
            led.on() if v else led.off()
        return func
    wifi_led = ledfunc(LED(1), 1)
    blue_led = ledfunc(LED(3), 0)
elif platform == 'rp2':
    from machine import Pin
    def ledfunc(pin):
        pin = pin
        def func(v):
            pin(v)
        return func
    wifi_led = lambda _ : None  # Only one LED
    LED = 'LED' if 'Pico W' in implementation._machine else 25
    blue_led = ledfunc(Pin(LED, Pin.OUT, value = 0))  # Message received
else:  # Assume no LEDs
    wifi_led = lambda _ : None
    blue_led = wifi_led
