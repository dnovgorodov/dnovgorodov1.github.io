# main.py — Damian's MQTT↔UART bridge
# Team 305 EGR314
# ESP32-S3, UART2 on pins TX=17 RX=16, MQTT over TLS
#
# bridges the team 64-byte UART daisy chain to an AWS MQTT broker
# cloud commands → team packets on UART
# ALL team packets from UART → cloud via MQTT (full bus visibility)

import ssl
import struct
from machine import UART, Pin
import uasyncio as asyncio
import time

from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import wifi_led, blue_led, config
from team_config import (
    MY_ID, BCAST, KNOWN_IDS,
    LIAM_ID, ISAIAH_ID, ARIANNA_ID, MYLES_ID, RAGUL_ID, DAMIAN_ID,
    BAUD_RATE, PKT_LEN,
    MQTT_SERVER, MQTT_USER, MQTT_PASSWORD,
    TOPIC_HB, TOPIC_PUB, TOPIC_SUB,
    WIFI_NETWORKS,
)
from uart_protocol import (
    build_packet, validate_packet, route_packet,
    build_ack, UARTReceiver,
)

# --- hardware ---
uart = UART(1, BAUD_RATE, tx=43, rx=44)
uart.init(BAUD_RATE, bits=8, parity=None, stop=1, flow=0)
ledMQTT_UART = Pin(40, Pin.OUT)
ledUART_MQTT = Pin(10, Pin.OUT)

async def blink_led(led, duration=2):
    led.on()
    await asyncio.sleep(duration)
    led.off()

mqtt_client = None
rx = UARTReceiver()
_last_tx_ms = 0
TX_GAP_MS = 80  # min ms between UART TX frames (~12.5 frames/s at 9600)

# --- node name lookup ---
NODE_NAMES = {
    0x43: 'Christo',
    0x4C: 'Liam',
    0x49: 'Isaiah',
    0x41: 'Arianna',
    0x4D: 'Myles',
    0x52: 'Ragul',
    0x44: 'Damian',
    0x58: 'ALL',
}

# message type names for human-readable MQTT output
MSG_NAMES = {
    0x01: 'motor_speed',
    0x03: 'camera_frame',
    0x04: 'camera_gyro',
    0x08: 'temperature',
    0x0A: 'pressure',
    0x0B: 'humidity',
    0x0C: 'distance',
    0xAA: 'ack',
}

# --- helpers ---

def _now():
    return time.ticks_ms()

def _can_send():
    return time.ticks_diff(_now(), _last_tx_ms) >= TX_GAP_MS

def _uart_send(pkt):
    global _last_tx_ms
    if pkt is None:
        return
    uart.write(pkt)
    _last_tx_ms = _now()

def _hex(byte_val):
    return '{:02X}'.format(byte_val)

def _hex_bytes(b):
    return ''.join('{:02X}'.format(x) for x in b)

def _node_name(node_id):
    return NODE_NAMES.get(node_id, '?{:02X}'.format(node_id))

def _msg_name(msg_type):
    return MSG_NAMES.get(msg_type, '0x{:02X}'.format(msg_type))

# --- parse known payloads into readable dict ---
def _parse_payload(msg_type, payload, sender):
    # returns a dict of human-readable fields for known message types
    result = {}
    try:
        # type 0x08: temperature from Isaiah, int16 x100 LE
        if msg_type == 0x08 and len(payload) >= 3:
            raw = struct.unpack('<h', payload[1:3])[0]
            result['temp_c'] = raw / 100.0
            result['temp_f'] = (raw / 100.0) * 9/5 + 32

        # type 0x0B: humidity from Isaiah, uint16 x100 LE
        elif msg_type == 0x0B and len(payload) >= 3:
            raw = struct.unpack('<H', payload[1:3])[0]
            result['humidity_pct'] = raw / 100.0

        # type 0x0A: pressure from Isaiah
        elif msg_type == 0x0A and len(payload) >= 9:
            pressure = struct.unpack('<I', payload[1:5])[0]
            altitude = struct.unpack('<i', payload[5:9])[0]
            result['pressure_pa'] = pressure
            result['altitude_cm'] = altitude

        # type 0x04: gyro from Ragul (3x int16 LE)
        elif msg_type == 0x04 and sender == RAGUL_ID and len(payload) >= 6:
            gx, gy, gz = struct.unpack('<hhh', payload[0:6])
            result['gyro_x'] = gx
            result['gyro_y'] = gy
            result['gyro_z'] = gz

        # type 0x04: camera state from Arianna
        elif msg_type == 0x04 and sender == ARIANNA_ID and len(payload) >= 7:
            cam_states = {0: 'Off', 1: 'Idle', 2: 'Capturing'}
            result['camera_state'] = cam_states.get(payload[1], str(payload[1]))
            result['camera_w'] = struct.unpack('<H', payload[2:4])[0] if len(payload) >= 4 else '?'
            result['camera_h'] = struct.unpack('<H', payload[4:6])[0] if len(payload) >= 6 else '?'
            result['camera_err'] = payload[6]

        # type 0x0C: distance from Myles, float LE
        elif msg_type == 0x0C and len(payload) >= 5:
            dist_m = struct.unpack('<f', payload[1:5])[0]
            result['distance_m'] = round(dist_m, 3)
            result['distance_cm'] = round(dist_m * 100, 1)

        # type 0x01: motor speed from HMI to Liam
        elif msg_type == 0x01 and len(payload) >= 1:
            spd = struct.unpack('<b', payload[0:1])[0]
            result['motor_speed'] = spd
            result['motor_dir'] = 'FWD' if spd >= 0 else 'REV'

        # type 0xAA: ACK
        elif msg_type == 0xAA and len(payload) >= 1:
            result['ack_for'] = '0x{:02X}'.format(payload[0])
    except Exception as e:
        result['parse_err'] = str(e)

    return result

# --- MQTT → UART (cloud commands enter the daisy chain) ---

def _parse_mqtt_msg(msg_str):
    # "msg_type;dest_id;data_hex" → (msg_type, dest_id, data_bytes)
    # e.g. "01;4C;64" → (0x01, 0x4C, b'\x64')
    #      "02;58;"   → (0x02, 0x58, b'')
    parts = msg_str.strip().rstrip(';').split(';')
    if len(parts) < 2:
        print('[MQTT] bad format, need msg_type;dest[;data]:', msg_str)
        return None
    try:
        msg_type = int(parts[0], 16)
        dest_id  = int(parts[1], 16)
        data = b''
        if len(parts) >= 3 and parts[2]:
            data = bytes.fromhex(parts[2])
        return (msg_type, dest_id, data)
    except ValueError as e:
        print('[MQTT] parse error:', e)
        return None

def sub_cb(topic, msg, retained):
    # MQTT subscription callback: parse cloud command → team packet → UART
    topic_s = topic.decode() if isinstance(topic, bytes) else topic
    #msg_s = msg.decode() if isinstance(msg, bytes) else msg
    msg_s = msg.decode() if isinstance(msg, (bytes, bytearray)) else msg
    print('[MQTT RX] topic={} msg="{}"'.format(topic_s, msg_s))
    
    loop = asyncio.get_event_loop()
    loop.create_task(ledMQTT_UART, blink_led(ledMQTT_UART))

    parsed = _parse_mqtt_msg(msg_s)
    if parsed is None:
        return

    msg_type, dest_id, data_bytes = parsed
    pkt = build_packet(dest_id, msg_type, data_bytes)
    if pkt is None:
        print('[MQTT] failed to build packet for cloud cmd')
        return

    print('[MQTT→UART] {} type={} dest={} data={}'.format(
        _msg_name(msg_type), _hex(msg_type), _node_name(dest_id), _hex_bytes(data_bytes)))
    _uart_send(pkt)

# --- UART packet handler (called by route_packet) ---

async def _publish_async(topic, msg, qos=1):
    if mqtt_client is None:
        return
    try:
        await mqtt_client.publish(topic, msg, qos=qos)
        loop = asyncio.get_event_loop()
        loop.create_task(ledUART_MQTT, blink_led(ledUART_MQTT))
    except Exception as e:
        print('[MQTT] publish error:', e)

def _build_mqtt_msg(msg_type, payload, sender):
    # build a human-readable MQTT message with parsed data
    sender_name = _node_name(sender)
    msg_name = _msg_name(msg_type)
    raw_hex = _hex_bytes(payload.strip(b'\x00'))

    parsed = _parse_payload(msg_type, payload, sender)

    # format: "SENDER TYPE raw=HEX key=val key=val ..."
    parts = ['{} {} raw={}'.format(sender_name, msg_name, raw_hex)]
    for k, v in parsed.items():
        parts.append('{}={}'.format(k, v))
    return ' '.join(parts)

def handle_uart_msg(msg_type, payload, sender):
    # called for packets addressed to Damian (0x44) or broadcast (0x58)
    msg_str = _build_mqtt_msg(msg_type, payload, sender)
    print('[UART→MQTT] {}'.format(msg_str))
    loop = asyncio.get_event_loop()
    loop.create_task(_publish_async(TOPIC_PUB, msg_str, qos=1))

def send_ack_uart(dest, received_type):
    pkt = build_ack(dest, received_type)
    _uart_send(pkt)

def forward_uart(pkt):
    # forward non-local packets on UART AND publish to MQTT for visibility
    sender = pkt[2]
    msg_type = pkt[4]
    payload = bytes(pkt[5:62])
    # publish to MQTT so the web interface sees ALL bus traffic
    msg_str = _build_mqtt_msg(msg_type, payload, sender)
    print('[FWD→MQTT] {}'.format(msg_str))
    loop = asyncio.get_event_loop()
    loop.create_task(_publish_async(TOPIC_PUB, msg_str, qos=1))
    # still forward on UART
    _uart_send(pkt)

# --- async tasks ---

async def uart_to_mqtt_task():
    # poll UART RX, feed state machine, route valid packets
    while True:
        packets = rx.feed(uart)
        for pkt in packets:
            sender = pkt[2]
            receiver = pkt[3]
            msg_type = pkt[4]
            print('[UART] {} → {} {}'.format(
                _node_name(sender), _node_name(receiver), _msg_name(msg_type)))
            route_packet(pkt, handle_uart_msg, send_ack_uart, forward_uart)
        await asyncio.sleep_ms(5)

async def heartbeat_task():
    # publish heartbeat counter every 5 seconds
    n = 0
    while True:
        await asyncio.sleep(5)
        if mqtt_client is not None:
            try:
                await mqtt_client.publish(TOPIC_HB, 'hb={}'.format(n), qos=1)
                print('[HB] {}'.format(n))
            except Exception as e:
                print('[HB] error:', e)
        n += 1

async def wifi_handler(state):
    wifi_led(not state)
    print('[WiFi] {}'.format('up' if state else 'down'))
    await asyncio.sleep(1)

async def conn_handler(client):
    global mqtt_client
    mqtt_client = client
    print('[MQTT] connected, subscribing to {}'.format(TOPIC_SUB))
    await client.subscribe(TOPIC_SUB, 1)

# --- MQTT client config ---

config['server'] = MQTT_SERVER
config['ssl'] = True

with open('certs/student_key.pem', 'rb') as f:
    key_data = f.read()
with open('certs/student_crt.pem', 'rb') as f:
    cert_data = f.read()
with open('certs/ca_crt.pem', 'rb') as f:
    ca_data = f.read()

ssl_params = {}
ssl_params['cert'] = cert_data
ssl_params['key'] = key_data
ssl_params['cadata'] = ca_data
ssl_params['server_hostname'] = MQTT_SERVER
ssl_params['cert_reqs'] = ssl.CERT_REQUIRED
config['ssl_params'] = ssl_params

config['subs_cb'] = sub_cb
config['wifi_coro'] = wifi_handler
config['connect_coro'] = conn_handler
config['clean'] = True
config['user'] = MQTT_USER
config['password'] = MQTT_PASSWORD
config['time_server'] = MQTT_SERVER
config['time_server_timeout'] = 10

config['ssid'] = WIFI_NETWORKS[0][0]
config['wifi_pw'] = WIFI_NETWORKS[0][1]

MQTTClient.DEBUG = True
client = MQTTClient(config)

# --- main ---

async def main(client):
    print('[BOOT] Damian MQTT bridge, node 0x{:02X}'.format(MY_ID))
    print('[BOOT] UART1 TX=43 RX=44 @ {} baud'.format(BAUD_RATE))
    print('[BOOT] MQTT broker {}:8883 TLS'.format(MQTT_SERVER))
    print('[BOOT] topics: PUB={} SUB={} HB={}'.format(TOPIC_PUB, TOPIC_SUB, TOPIC_HB))
    print('[BOOT] team nodes: {}'.format(', '.join('{}={}'.format(v, k) for k, v in sorted(NODE_NAMES.items()))))

    try:
        await client.connect()
    except OSError as e:
        print('[BOOT] MQTT connection failed:', e)
        return

    asyncio.create_task(uart_to_mqtt_task())
    asyncio.create_task(heartbeat_task())

    while True:
        await asyncio.sleep(3600)

try:
    asyncio.run(main(client))
finally:
    client.close()
    asyncio.new_event_loop()

