# team_config.py
# Team 305 EGR314 shared protocol constants
# IDs, reserved bytes, packet params.


# --- packet framing ---

PKT_LEN = 64
PREFIX  = (0xA5, 0x5A)
SUFFIX  = (0x59, 0x42)

# union of prefix + suffix bytes, every node must escape these from payloads
RESERVED_TEAM = (0xA5, 0x5A, 0x59, 0x42)

# per-node extra reserved byte, None means unconfirmed
RESERVED_NODE = {
    0x43: None,   # Christo
    0x4C: None,   # Liam
    0x49: None,   # Isaiah
    0x41: None,   # Arianna
    0x4D: None,   # Myles
    0x52: None,   # Ragul
    0x44: None,   # Damian
}


def reserved_bytes_for(node_id):
    # return team + node-specific reserved bytes
    extra = RESERVED_NODE.get(node_id)
    if extra is not None:
        return RESERVED_TEAM + (extra,)
    return RESERVED_TEAM


# --- node IDs ---

MY_ID      = 0x44   # Damian (MQTT bridge)
LIAM_ID    = 0x4C
ISAIAH_ID  = 0x49
ARIANNA_ID = 0x41
MYLES_ID   = 0x4D
RAGUL_ID   = 0x52
DAMIAN_ID  = 0x44
BCAST      = 0x58   # broadcast target, goes to all nodes

# all recognized source/dest IDs
KNOWN_IDS  = (0x43, LIAM_ID, ISAIAH_ID, ARIANNA_ID, MYLES_ID, RAGUL_ID, DAMIAN_ID, BCAST)


# --- UART ---

BAUD_RATE = 9600    # team-agreed bus speed

# --- WiFi (MQTT node) ---
WIFI_NETWORKS = [
    ("Christo’s iPhone", 'christo2005'),
    ('SETUP-6B60',       'fifty0382artist'),   # home
]

# --- MQTT ---
MQTT_SERVER   = '34.210.232.255'
MQTT_USER     = 'student'
MQTT_PASSWORD = 'egr3x4'
TEAM_TOPIC    = 'EGR314/Team305/DN'
TOPIC_HB      = TEAM_TOPIC + 'heartbeat'
TOPIC_PUB     = TEAM_TOPIC + 'PUB'
TOPIC_SUB     = TEAM_TOPIC + 'SUB'
