# boot.py — Damian MQTT bridge
